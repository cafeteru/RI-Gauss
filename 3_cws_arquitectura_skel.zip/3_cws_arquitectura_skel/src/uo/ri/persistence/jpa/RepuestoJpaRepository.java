package uo.ri.persistence.jpa;

import uo.ri.business.repository.RepuestoRepository;
import uo.ri.model.Repuesto;
import uo.ri.persistence.jpa.util.BaseRepository;

public class RepuestoJpaRepository extends BaseRepository<Repuesto>
		implements RepuestoRepository {

}
