package uo.ri.business.repository;

import uo.ri.model.Cliente;

public interface ClienteRepository extends Repository<Cliente> {

}
