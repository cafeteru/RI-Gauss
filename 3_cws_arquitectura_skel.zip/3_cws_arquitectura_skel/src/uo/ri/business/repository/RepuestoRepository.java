package uo.ri.business.repository;

import uo.ri.model.Repuesto;

public interface RepuestoRepository extends Repository<Repuesto> {

}
