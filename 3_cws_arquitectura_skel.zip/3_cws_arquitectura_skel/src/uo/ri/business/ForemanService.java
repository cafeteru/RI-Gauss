package uo.ri.business;

public interface ForemanService {

	// esta funcionalidad está sin implementar

}
