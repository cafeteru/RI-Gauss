package uo.ri.business.dto;

public class VoucherDto extends PaymentMeanDto {

	public String code;
	public String description;
	public Double available;

}
