package uo.ri.business.dto;

public class CashDto extends PaymentMeanDto {

}
