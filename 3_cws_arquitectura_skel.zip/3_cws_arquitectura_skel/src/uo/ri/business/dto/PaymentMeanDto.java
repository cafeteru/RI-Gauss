package uo.ri.business.dto;

public abstract class PaymentMeanDto {
	public Long id;
	public Long clientId;
	public Double accumulated;

}
