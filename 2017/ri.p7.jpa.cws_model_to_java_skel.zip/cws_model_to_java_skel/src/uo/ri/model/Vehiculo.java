package uo.ri.model;

public class Vehiculo {
	
	private String marca;
	private String matricula;
	private String modelo;
	
	private int numAverias = 0;
	
}
