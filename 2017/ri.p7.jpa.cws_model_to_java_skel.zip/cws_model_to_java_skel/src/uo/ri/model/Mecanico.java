package uo.ri.model;

public class Mecanico {

	private String dni;
	private String apellidos;
	private String nombre;

}
