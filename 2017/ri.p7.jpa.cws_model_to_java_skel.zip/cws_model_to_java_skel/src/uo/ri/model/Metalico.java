package uo.ri.model;

public class Metalico extends MedioPago {

}
