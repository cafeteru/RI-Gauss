package uo.ri.model;

public class Repuesto  {

	private String codigo;
	private String descripcion;
	private double precio;
	
}
