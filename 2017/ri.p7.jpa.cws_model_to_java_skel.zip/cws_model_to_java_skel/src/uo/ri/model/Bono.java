package uo.ri.model;

public class Bono extends MedioPago {

	private double disponible = 0.0;
	private String descripcion;
	private String codigo;
	
}
