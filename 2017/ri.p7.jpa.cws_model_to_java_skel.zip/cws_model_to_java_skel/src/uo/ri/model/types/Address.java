package uo.ri.model.types;

public class Address {

	private String street;
	private String city;
	private String zipcode;
}
