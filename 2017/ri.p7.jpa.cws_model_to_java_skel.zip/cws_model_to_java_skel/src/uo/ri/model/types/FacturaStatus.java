package uo.ri.model.types;

public enum FacturaStatus {
	
	SIN_ABONAR,
	ABONADA

}
