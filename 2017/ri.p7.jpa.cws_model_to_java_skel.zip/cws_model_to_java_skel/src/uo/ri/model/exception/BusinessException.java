package uo.ri.model.exception;

public class BusinessException extends Exception {
	private static final long serialVersionUID = 4001710687990554589L;

	public BusinessException() {
	}

	public BusinessException(String message) {
		super(message);
	}

	public BusinessException(Throwable cause) {
		super(cause);
	}

	public BusinessException(String message, Throwable cause) {
		super(message, cause);
	}

}
