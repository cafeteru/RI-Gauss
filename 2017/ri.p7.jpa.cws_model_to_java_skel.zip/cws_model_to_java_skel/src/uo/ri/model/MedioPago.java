package uo.ri.model;

public abstract class MedioPago {

	protected double acumulado = 0.0;
	
}
