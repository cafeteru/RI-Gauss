package uo.ri.model;

public class TarjetaCredito extends MedioPago {

	private String numero;
	private String tipo;
	private Date validez;
	
}
