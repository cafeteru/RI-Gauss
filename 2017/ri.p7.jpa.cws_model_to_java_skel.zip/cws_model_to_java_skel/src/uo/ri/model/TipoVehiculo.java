package uo.ri.model;

public class TipoVehiculo {
	
	private String nombre;
	private double precioHora;

}
