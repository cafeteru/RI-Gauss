package uo.ri.model;

import uo.ri.model.types.Address;

public class Cliente {
	
	private String dni;
	private String nombre;
	private String apellidos;
	private Address address;
	

}

