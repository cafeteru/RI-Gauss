package uo.ri.model;

public class Sustitucion {
	
	private Repuesto repuesto;
	private Intervencion intervencion;
	private int cantidad;


}
