package uo.ri.business;

public interface MechanicService {

	// esta funcionalidad está sin implementar

}
