package uo.ri.business.impl.admin;

import java.util.List;

import uo.ri.business.dto.MechanicDto;

public class FindAllMechanics {

	public List<MechanicDto> execute() {

		return null;
	}

}
