package uo.ri.business.impl;

public interface ComandExecutorFactory {

	CommandExecutor forExecutor();

}
