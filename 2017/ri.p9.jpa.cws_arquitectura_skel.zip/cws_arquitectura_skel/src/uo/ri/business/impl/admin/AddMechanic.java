package uo.ri.business.impl.admin;

import uo.ri.business.dto.MechanicDto;


public class AddMechanic {

	private MechanicDto dto;

	public AddMechanic(MechanicDto mecanico) {
		this.dto = mecanico;
	}

	public Void execute() {

		return null;
	}

}
