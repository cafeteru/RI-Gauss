package uo.ri.business.impl.admin;

import uo.ri.util.exception.BusinessException;

public class DeleteMechanic {

	private Long idMecanico;

	public DeleteMechanic(Long idMecanico) {
		this.idMecanico = idMecanico;
	}

	public Void execute() throws BusinessException {

		return null;
	}

}
