package uo.ri.business.impl.admin;

import uo.ri.business.dto.MechanicDto;
import uo.ri.util.exception.BusinessException;

public class UpdateMechanic {

	private MechanicDto dto;

	public UpdateMechanic(MechanicDto dto) {
		this.dto = dto;
	}

	public Void execute() throws BusinessException {

		return null;
	}

}
