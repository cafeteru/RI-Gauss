package uo.ri.persistence.jpa;

import java.util.List;

import uo.ri.business.repository.MecanicoRepository;

public class MechanicJpaRepository 
		implements MecanicoRepository {

	@Override
	public void add(Mecanico t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(Mecanico t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mecanico findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Mecanico> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
