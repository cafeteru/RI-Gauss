package uo.ri.business.repository;

import uo.ri.model.Recomendacion;

public interface RecomendacionRepository extends Repository<Recomendacion> {

}
