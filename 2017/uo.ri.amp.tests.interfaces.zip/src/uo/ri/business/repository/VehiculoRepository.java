package uo.ri.business.repository;

import uo.ri.model.Vehiculo;

public interface VehiculoRepository extends Repository<Vehiculo> {

}
