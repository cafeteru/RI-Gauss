package uo.ri.amp.util.repository.inmemory;

import uo.ri.business.repository.RecomendacionRepository;
import uo.ri.model.Recomendacion;

public class InMemoryRecomendacionRepository 
		extends BaseMemoryRepository<Recomendacion>
		implements RecomendacionRepository {

}
