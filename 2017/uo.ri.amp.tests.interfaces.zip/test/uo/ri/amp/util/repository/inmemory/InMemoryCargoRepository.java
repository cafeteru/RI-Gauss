package uo.ri.amp.util.repository.inmemory;

import uo.ri.business.repository.CargoRepository;
import uo.ri.model.Cargo;

public class InMemoryCargoRepository 
		extends BaseMemoryRepository<Cargo> 
		implements CargoRepository {
}
