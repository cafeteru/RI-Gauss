package uo.ri.amp.util.repository.inmemory;

import uo.ri.business.repository.VehiculoRepository;
import uo.ri.model.Vehiculo;

public class InMemoryVehiculoRepository 
		extends BaseMemoryRepository<Vehiculo> 
		implements VehiculoRepository {

}
