package uo.ri.business.impl;

public interface CommandExecutorFactory {

	CommandExecutor forExecutor();

}
