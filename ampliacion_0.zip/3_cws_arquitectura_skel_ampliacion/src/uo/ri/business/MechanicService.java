package uo.ri.business;

public interface MechanicService {

	// not yet implemented...

}
