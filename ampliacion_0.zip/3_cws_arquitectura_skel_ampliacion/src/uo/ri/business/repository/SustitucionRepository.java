package uo.ri.business.repository;

import uo.ri.model.Sustitucion;

public interface SustitucionRepository extends Repository<Sustitucion> {

}
