package uo.ri.business.repository;

import uo.ri.model.TipoVehiculo;

public interface TipoVehiculoRepository extends Repository<TipoVehiculo> {

}
