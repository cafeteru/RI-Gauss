package uo.ri.business.repository;

import uo.ri.model.Cargo;

public interface CargoRepository extends Repository<Cargo> {

}
