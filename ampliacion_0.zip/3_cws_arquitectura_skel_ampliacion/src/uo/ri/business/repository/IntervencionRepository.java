package uo.ri.business.repository;

import uo.ri.model.Intervencion;

public interface IntervencionRepository extends Repository<Intervencion> {

}
