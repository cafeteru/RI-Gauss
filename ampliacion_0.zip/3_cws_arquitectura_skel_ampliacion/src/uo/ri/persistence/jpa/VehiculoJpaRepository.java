package uo.ri.persistence.jpa;

import uo.ri.business.repository.VehiculoRepository;
import uo.ri.model.Vehiculo;
import uo.ri.persistence.jpa.util.BaseRepository;

public class VehiculoJpaRepository extends BaseRepository<Vehiculo>
		implements VehiculoRepository {

}
