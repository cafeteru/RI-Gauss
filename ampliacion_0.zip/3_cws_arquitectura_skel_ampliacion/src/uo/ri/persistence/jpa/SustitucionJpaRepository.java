package uo.ri.persistence.jpa;

import uo.ri.business.repository.SustitucionRepository;
import uo.ri.model.Sustitucion;
import uo.ri.persistence.jpa.util.BaseRepository;

public class SustitucionJpaRepository extends BaseRepository<Sustitucion>
		implements SustitucionRepository {

}
