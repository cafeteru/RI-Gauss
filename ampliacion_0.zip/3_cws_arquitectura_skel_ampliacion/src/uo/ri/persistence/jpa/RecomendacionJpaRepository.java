package uo.ri.persistence.jpa;

import uo.ri.business.repository.RecomendacionRepository;
import uo.ri.model.Recomendacion;
import uo.ri.persistence.jpa.util.BaseRepository;

public class RecomendacionJpaRepository extends BaseRepository<Recomendacion>
		implements RecomendacionRepository {

}
