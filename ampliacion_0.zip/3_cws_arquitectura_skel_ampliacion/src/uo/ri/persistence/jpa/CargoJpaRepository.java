package uo.ri.persistence.jpa;

import uo.ri.business.repository.CargoRepository;
import uo.ri.model.Cargo;
import uo.ri.persistence.jpa.util.BaseRepository;

public class CargoJpaRepository extends BaseRepository<Cargo>
		implements CargoRepository {

}
