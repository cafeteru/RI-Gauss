package uo.ri.persistence.jpa;

import uo.ri.business.repository.IntervencionRepository;
import uo.ri.model.Intervencion;
import uo.ri.persistence.jpa.util.BaseRepository;

public class IntervencionJpaRepository extends BaseRepository<Intervencion>
		implements IntervencionRepository {

}
