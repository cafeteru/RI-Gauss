package uo.ri.persistence.jpa;

import uo.ri.business.repository.TipoVehiculoRepository;
import uo.ri.model.TipoVehiculo;
import uo.ri.persistence.jpa.util.BaseRepository;

public class TipoVehiculoJpaRepository extends BaseRepository<TipoVehiculo>
		implements TipoVehiculoRepository {

}
