package uo.ri.ui.cash.action.factura;

import uo.ri.ui.util.Action;
import uo.ri.util.exception.BusinessException;

public class BuscarFacturaMatriculaAction implements Action {

	@Override
	public void execute() throws BusinessException {
		// TODO Auto-generated method stub

	}

}
