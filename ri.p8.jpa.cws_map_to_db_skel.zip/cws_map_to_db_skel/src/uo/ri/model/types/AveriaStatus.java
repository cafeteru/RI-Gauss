package uo.ri.model.types;

public enum AveriaStatus {
	ABIERTA,
	ASIGNADA,
	TERMINADA,
	FACTURADA
}
